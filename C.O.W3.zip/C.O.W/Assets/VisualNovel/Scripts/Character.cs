﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class Character 
{
	public string characterName;

	[HideInInspector]public RectTransform root;

	public bool enabled {get{ return root.gameObject.activeInHierarchy;} set{ root.gameObject.SetActive (value);}}

	public Vector2 anchorPadding {get{ return root.anchorMax - root.anchorMin;}}

	DialogueSystem dialogue;

	public void Say(string speech, bool add = false)
	{
		if (!enabled)
			enabled = true;

		if (!add)
			dialogue.Say (speech, characterName);
		else
			dialogue.SayAdd (speech, characterName);
	}

	public Sprite GetSprite(int index = 0)
	{
		Sprite[] sprites = Resources.LoadAll<Sprite> ("Images/Characters/" + characterName);
		return sprites[index];
	}

	public void SetBody(int index)
	{
		renderers.bodyRenderer.sprite = GetSprite (index);
	}
	public void SetBody(Sprite sprite)
	{
		renderers.bodyRenderer.sprite = sprite;
	}
		
	public Character (string _name, bool enableOnStart = true)
	{
		CharacterManager cm = CharacterManager.instance;
		GameObject prefab = Resources.Load ("Characters/Character[" + _name + "]") as GameObject;
		GameObject ob = GameObject.Instantiate (prefab, cm.characterPanel);

		root = ob.GetComponent<RectTransform> ();
		characterName = _name;

		renderers.bodyRenderer = ob.transform.Find ("BodyLayer").GetComponentInChildren<Image> ();

		dialogue = DialogueSystem.instance;

		enabled = enableOnStart;
	}

	[System.Serializable]
	public class Renderers
	{
		public Image bodyRenderer;
	}

	public Renderers renderers = new Renderers();
}
