﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemAreaSpawner : MonoBehaviour {

    private int cowtype;

    public GameObject cow01;
    public GameObject cow02;
    public GameObject cow03;
    public GameObject cow04;
    public GameObject cow05;
    public GameObject cow06;
    public GameObject cow07;
    public GameObject cow08;
    public GameObject cow09;
    public GameObject cow10;
    public GameObject cow11;
    public GameObject cow12;
    public GameObject cow13;
    public GameObject cow14;
    public GameObject cow15;


    public GameObject badcow01;
    public GameObject badcow02;
    public GameObject badcow03;
    public GameObject badcow04;
    public GameObject badcow05;

    public static int numcow01 = 10;
    public static int numcow02 = 1;

    public float itemXSpread = 3.0f;
    public float itemYSpread = 3.0f;
    public float itemZSpread = 0;

	void Start () {
        GeneratingCows();
        GeneratingBadCows();
	}

    public void GeneratingCows()
    {
        for (int i = 0; i < numcow01; i++)
        {
            cowtype = Random.Range(0, 14);

            switch (cowtype)
            {

            case 0:
            if (cow01 != null)
            {
              SpreadItem(cowtype);
            }
            break;

            case 1:
                    if (cow02 != null)
                    {
                        SpreadItem(cowtype);
                    }
                    break;

                case 2:
                    if (cow03 != null)
                    {
                        SpreadItem(cowtype);
                    }
                    break;

                case 3:
                    if (cow04 != null)
                    {
                        SpreadItem(cowtype);
                    }
                    break;

                case 4:
                    if (cow05 != null)
                    {
                        SpreadItem(cowtype);
                    }
                    break;

                case 5:
                    if (cow06 != null)
                    {
                        SpreadItem(cowtype);
                    }
                    break;

                case 6:
                    if (cow07 != null)
                    {
                        SpreadItem(cowtype);
                    }
                    break;
                case 7:
                    if (cow08 != null)
                    {
                        SpreadItem(cowtype);
                    }
                    break;

                case 8:
                    if (cow09 != null)
                    {
                        SpreadItem(cowtype);
                    }
                    break;

                case 9:
                    if (cow10 != null)
                    {
                        SpreadItem(cowtype);
                    }
                    break;
                case 10:
                    if (cow11 != null)
                    {
                        SpreadItem(cowtype);
                    }
                    break;
                case 11:
                    if (cow12 != null)
                    {
                        SpreadItem(cowtype);
                    }
                    break;
                case 12:
                    if (cow13 != null)
                    {
                        SpreadItem(cowtype);
                    }
                    break;
                case 13:
                    if (cow14 != null)
                    {
                        SpreadItem(cowtype);
                    }
                    break;
                case 14:
                    if (cow15 != null)
                    {
                        SpreadItem(cowtype);
                    }
                    break;
            }
        }
    }
	
    public void SpreadItem(int incowtype)
    {
        Vector3 randPosition = new Vector3
            (Random.Range(-itemXSpread, itemXSpread),
                Random.Range(-itemYSpread, itemYSpread), 
                    Random.Range(-itemZSpread, itemZSpread));

        if (incowtype == 0 ){
        GameObject clone = Instantiate(cow01, randPosition, Quaternion.identity);
        }

        if (incowtype == 1) {
            GameObject clone = Instantiate(cow02, randPosition, Quaternion.identity);
        }
        if (incowtype == 2) {
            GameObject clone = Instantiate(cow03, randPosition, Quaternion.identity);
        }
        if (incowtype == 3) {
            GameObject clone = Instantiate(cow04, randPosition, Quaternion.identity);
        }
        if (incowtype == 4) {
            GameObject clone = Instantiate(cow05, randPosition, Quaternion.identity);
        }
        if (incowtype == 5) {
            GameObject clone = Instantiate(cow06, randPosition, Quaternion.identity);
        }
        if (incowtype == 6) {
            GameObject clone = Instantiate(cow07, randPosition, Quaternion.identity);
        }
        if (incowtype == 7) {
            GameObject clone = Instantiate(cow08, randPosition, Quaternion.identity);
        }
        if (incowtype == 8) {
            GameObject clone = Instantiate(cow09, randPosition, Quaternion.identity);
        }
        if (incowtype == 9) {
            GameObject clone = Instantiate(cow10, randPosition, Quaternion.identity);
        }
        if (incowtype == 10) {
            GameObject clone = Instantiate(cow11, randPosition, Quaternion.identity);
        }
        if (incowtype == 11) {
            GameObject clone = Instantiate(cow12, randPosition, Quaternion.identity);
        }
        if (incowtype == 12) {
            GameObject clone = Instantiate(cow13, randPosition, Quaternion.identity);
        }
        if (incowtype == 13) {
            GameObject clone = Instantiate(cow14, randPosition, Quaternion.identity);
        }
        if (incowtype == 14)  {
            GameObject clone = Instantiate(cow15, randPosition, Quaternion.identity);
        }
    }

    /// <summary>
    /// //////////////////////////////////////////////////////////////////////////////////////
    /// </summary>
    /// 



    public void GeneratingBadCows()
    {
        for (int i = 0; i < numcow02; i++)
        {
            cowtype = Random.Range(0, 4);

            switch (cowtype)
            {

                case 0:
                    if (badcow01 != null)
                    {
                        SpreadItem2(cowtype);
                    }
                    break;

                case 1:
                    if (badcow02 != null)
                    {
                        SpreadItem2(cowtype);
                    }
                    break;

                case 2:
                    if (badcow03 != null)
                    {
                        SpreadItem2(cowtype);
                    }
                    break;

                case 3:
                    if (badcow04 != null)
                    {
                        SpreadItem2(cowtype);
                    }
                    break;

                case 4:
                    if (badcow05 != null)
                    {
                        SpreadItem2(cowtype);
                    }
                    break;

            }
        }
    }

    public void SpreadItem2(int incowtype)
    {
        Vector3 randPosition = new Vector3
            (Random.Range(-itemXSpread, itemXSpread),
                Random.Range(-itemYSpread, itemYSpread),
                    Random.Range(-itemZSpread, itemZSpread));

        if (incowtype == 0)
        {
            GameObject clone = Instantiate(badcow01, randPosition, Quaternion.identity);
        }

        if (incowtype == 1)
        {
            GameObject clone = Instantiate(badcow02, randPosition, Quaternion.identity);
        }
        if (incowtype == 2)
        {
            GameObject clone = Instantiate(badcow03, randPosition, Quaternion.identity);
        }
        if (incowtype == 3)
        {
            GameObject clone = Instantiate(badcow04, randPosition, Quaternion.identity);
        }
        if (incowtype == 4)
        {
            GameObject clone = Instantiate(badcow05, randPosition, Quaternion.identity);
        }
    }

    }
