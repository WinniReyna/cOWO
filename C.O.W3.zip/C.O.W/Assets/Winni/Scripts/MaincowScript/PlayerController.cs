﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
    public float rayLength;
    public float Round = 3;
   

    [SerializeField] private GameObject itemArespawn;


    private void LateUpdate()
    {
        if (Input.GetMouseButtonDown(0) && PauseMenu.GameisPaused == false)
        {
            RaycastHit hit;
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            if(Physics.Raycast(ray, out hit))
            {
                if(hit.transform.tag == "Good")
                {
                    Debug.Log("Holi, soy una buena vaca!");
                    Health.health -= 1;
                  
                }
                if (hit.transform.tag == "Devil")
                {
                    Debug.Log("Holi, soy una mala vaca! Round1");

                   /* foreach (GameObject respawn in respawns)
                    {

                    }*/
                }
                
            }
            }
        }
    }



