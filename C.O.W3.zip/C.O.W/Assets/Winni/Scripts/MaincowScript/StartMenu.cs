﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class StartMenu : MonoBehaviour {

    public GameObject Panel;

    private void Start()
    {
        Panel.gameObject.SetActive(false);
    }

    public void Load(int sceneIndex)
    {
        SceneManager.LoadScene(sceneIndex);
    }

    public void Quit()
    {
        Application.Quit();
        Debug.Log("Quit");
    }

    public void EnableControls()
    {
        Panel.SetActive(true);
    }

    public void DisableControls()
    {
        Panel.SetActive(false);
    }
}
