﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine;

public class Timer : MonoBehaviour
{
    public Text Contador;
    public float tiempo;
    private Text TotalTime;
    public float Evil_time;

     void Start()
    {
        Contador.text = " " + tiempo;

        TotalTime = GameObject.FindGameObjectWithTag("Time").GetComponent<Text>();
 
    }
    void Update()
    {
        tiempo -= Time.deltaTime;
        Contador.text = " " + tiempo.ToString("f0");
        TotalTime.text = tiempo.ToString();
        if (tiempo < 0)
        {
            SceneManager.LoadScene("End");
        }
    }

    void OnMouseDown()
    {
        if (gameObject.tag=="Devil")
        {
            tiempo -= Evil_time;
        }
      
    }
}
