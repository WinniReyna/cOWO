﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Text;

public class enemyspawnerScript : MonoBehaviour
{
   /* public GameObject redCube;// Prefab que se debe crear.
    public GameObject blueCube;
    public GameObject greenCube;

    List<GameObject> reds;
    List<GameObject> blues;
    List<GameObject> greens;

    private readonly int redpooled=1;
    private readonly int bluepooled=1;
    private readonly int greepooled=1;

    private  float x,y,z;
    private Vector3 pos;

    private readonly float spawnTime = 3f;            // Tiempo para realizar el spawn.
    private int maxSpawn = 1;            // Maximo de objetos a crear.
    private int spawned;
    private int enemyType;
    private bool spawnedAlredy;
    private int timeBetweenWaves;
    private static bool clearedWave;

    public bool randomizePosition;

    private void Start()
    {
        timeBetweenWaves = Random.Range(7, 15);

        if (redCube != null)
        {
            reds = new List<GameObject>();

            for (int i = 0; i < redpooled; i++)
            {
                GameObject obj = (GameObject)Instantiate(redCube);
                obj.SetActive(false);
                reds.Add(obj);
            }
        }

        if (blueCube != null)
        {
            blues = new List<GameObject>();

            for (int i = 0; i < bluepooled; i++)
            {
                GameObject obj = (GameObject)Instantiate(blueCube);
                obj.SetActive(false);
                blues.Add(obj);
            }
        }

        if (greenCube != null)
        {
            greens = new List<GameObject>();

            for (int i = 0; i < greepooled; i++)
            {
                GameObject obj = (GameObject)Instantiate(greenCube);
                obj.SetActive(false);
                greens.Add(obj);
            }
        }
    }

    void LateUpdate()
    {
        if (AnimationManager.augmentedStatus == true && this.gameObject.activeInHierarchy && HermesGameController.playerHealth>0)
        {
            if (spawnedAlredy == false)
            {
                Spawn();
                spawnedAlredy = true;
            }
        }

        if (HermesGameController.actualWave==1)
        {
            maxSpawn = 1;
        }
    }

    void Spawn()
    {
        if (spawned < maxSpawn)
        {
            StartCoroutine("WaveSpawn");
            Debug.Log("iniciandospawn");
        }

        else
        {
            Debug.Log("ya acabe de spawnear");
            clearedWave = true;
            StartCoroutine("WaveWait");
        }
    }

    IEnumerator WaveSpawn()
    {
        yield return new WaitForSeconds(spawnTime);
        SpawnEnemy();
        spawnedAlredy = false;
    }

    IEnumerator WaveWait()
    {
    if (clearedWave == true)
        {
        clearedWave = false;
        Debug.Log("ahora espero...");
        yield return new WaitForSeconds(timeBetweenWaves);
        Debug.Log("ya me canse de esperar " + timeBetweenWaves);
        maxSpawn += 1;
        spawned = 0;
        spawnedAlredy = false;

        HermesGameController.changeWave = true;
        }
    }

    private void SpawnEnemy()
    {
        //actual wave en enemytype para mas enemigos
        enemyType = Random.Range(0, 3);

        x = Random.Range(-15, 15);
        y = Random.Range(10, 30);
        z = Random.Range(-15, 15);
        pos = new Vector3(x, y, z);

        switch (enemyType)
        {
            case 0:
                if (redCube != null)
                {
                    for (int i = 0; i < reds.Count; i++)
                    {
                        if (!reds[i].activeInHierarchy)
                        {
                            reds[i].transform.position = randomizePosition == false ? transform.position : pos;
                            reds[i].transform.rotation = transform.rotation;
                            reds[i].SetActive(true);
                            break;
                        }
                    }
                }
                spawned++;
                break;
            case 1:
                if (blueCube != null)
                {
                    for (int i = 0; i < blues.Count; i++)
                    {
                        if (!blues[i].activeInHierarchy)
                        {
                            blues[i].transform.position = randomizePosition == false ? transform.position : pos;
                            blues[i].transform.rotation = transform.rotation;
                            blues[i].SetActive(true);
                            break;
                        }
                    }
                }
                spawned++;
                break;
            case 2:
                if (greenCube != null)
                {
                    for (int i = 0; i < greens.Count; i++)
                    {
                        if (!greens[i].activeInHierarchy)
                        {
                            greens[i].transform.position = randomizePosition == false ? transform.position : pos;
                            greens[i].transform.rotation = transform.rotation;
                            greens[i].SetActive(true);
                            break;
                        }
                    }
                }
                spawned++;
                break;
        }
    }

    private void OnEnable()
    {
        spawnedAlredy = false;
    }*/
}//class
