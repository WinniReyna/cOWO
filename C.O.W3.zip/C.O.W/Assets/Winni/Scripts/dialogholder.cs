﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class dialogholder : MonoBehaviour
{
	//public string dialogue;
	private DialogueManager dMan;

	public string[] dialogLines;

    void Start()
    {
		dMan = FindObjectOfType<DialogueManager>();
    }

	void OnMouseOver()
	{
		if (Input.GetMouseButtonDown(0))
		{
			//dMan.ShowBox (dialogue);
			if(!dMan.dialogActive)
			{
				dMan.dialogLines = dialogLines;
				dMan.currentLine = 0;
				dMan.ShowDialogue();
			}
		}
	}
}
